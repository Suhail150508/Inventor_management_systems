<!-- start: JavaScript-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.min.js" integrity="sha512-WW8/jxkELe2CAiE4LvQfwm1rajOS8PHasCCx+knHG0gBHt8EXxS6T6tJRTGuDQVnluuAvMxWF4j8SNFDKceLFg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script src="admin/js/jquery-1.9.1.min.js"></script>
<script src="admin/js/jquery-migrate-1.0.0.min.js"></script>

<script src="admin/js/jquery-ui-1.10.0.custom.min.js"></script>

<script src="admin/js/jquery.ui.touch-punch.js"></script>

<script src="admin/js/modernizr.js"></script>

<script src="admin/js/bootstrap.min.js"></script>

<script src="admin/js/jquery.cookie.js"></script>

<script src='admin/js/fullcalendar.min.js'></script>

<script src='admin/js/jquery.dataTables.min.js'></script>

<script src="admin/js/excanvas.js"></script>
<script src="admin/js/jquery.flot.js"></script>
<script src="admin/js/jquery.flot.pie.js"></script>
<script src="admin/js/jquery.flot.stack.js"></script>
<script src="admin/js/jquery.flot.resize.min.js"></script>

<script src="admin/js/jquery.chosen.min.js"></script>

<script src="admin/js/jquery.uniform.min.js"></script>

<script src="admin/js/jquery.cleditor.min.js"></script>

<script src="admin/js/jquery.noty.js"></script>

<script src="admin/js/jquery.elfinder.min.js"></script>

<script src="admin/js/jquery.raty.min.js"></script>

<script src="admin/js/jquery.iphone.toggle.js"></script>

<script src="admin/js/jquery.uploadify-3.1.min.js"></script>

<script src="admin/js/jquery.gritter.min.js"></script>

<script src="admin/js/jquery.imagesloaded.js"></script>

<script src="admin/js/jquery.masonry.min.js"></script>

<script src="admin/js/jquery.knob.modified.js"></script>

<script src="admin/js/jquery.sparkline.min.js"></script>

<script src="admin/js/counter.js"></script>

<script src="admin/js/retina.js"></script>

<script src="admin/js/custom.js"></script>
<!-- end: JavaScript-->
