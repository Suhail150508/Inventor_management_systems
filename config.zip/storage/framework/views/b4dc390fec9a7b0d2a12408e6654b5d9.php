<?php $__env->startSection('content'); ?>

<style>

@media (max-width: 700px) {
    .row-fluid{

    }

    #content{
        padding-left: 4rem;
    }
    .title_info h1{
        font-size: 1.4rem;
        /* width:80%; */
        margin-right: 2rem;

    }
}

</style>

<body>
		<!-- start: Header -->

	<!-- start: Header -->

	<div class="container-fluid-full"  style="width:95%">
		<div class="row-fluid">

			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>

			<!-- start: Content -->
			<div id="content" class="span10">

				<div class="title_info" style="width:90%">
					<h1 style="text-align: center">Sales Information</h1>
				</div>

				<div class="row-fluid" style="margin-left:-3rem">

					<div class="span3 statbox purple" onTablet="span6" onDesktop="span3">
						<div class="boxchart"></div>
						<?php
							use Carbon\Carbon;
							use App\Models\Sales_invoice;
							$amounts = Sales_invoice::whereDate('created_at', Carbon::today())->get();
							$sales_amount = 0;
                            $sales_due = 0;
                            ?>

							<?php $__currentLoopData = $amounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $sales_amount += $amount->sub_total;
                                    $sales_due += $amount->due
                                ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<?php if($sales_amount): ?>
						
						<div class="">
							Today Sales Amount
						</div>
						<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e($sales_amount); ?></div>

						<?php else: ?>
						
						<div class="">
							Today Sales Amount
						</div>
						<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e(0); ?></div>

						<?php endif; ?>
					</div>
					<div class="span3 statbox green" onTablet="span6" onDesktop="span3">
						<div class="boxchart"></div>
						<?php if($sales_due): ?>
						<div class="">
							Today Sales Due
						</div>
						<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e($sales_due); ?></div>

						<?php else: ?>
						<div class="">
							Today Sales Due
						</div>
						<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e(0); ?></div>

						<?php endif; ?>
					</div>

					<?php
						use App\Models\Return_Sales_Invoice;

						$return_customers = Return_Sales_Invoice::whereDate('created_at', Carbon::today())->get();
						// $return_customer = Return_Sales_Invoice::all();
                        $return_amount = 0;
					?>

                    <?php $__currentLoopData = $return_customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $return_customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $return_amount += $return_customer->sub_total;
                        // $sales_due += $amount->due
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<div class="span3 statbox blue noMargin" onTablet="span6" onDesktop="span3">
						<div class="boxchart"></div>

						<?php if(!$return_amount ): ?>

						<div class="">
							Today Customer Return
						</div>
						<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e(0); ?></div>

						<?php endif; ?>
						<?php if($return_amount ): ?>
						<div class="">
							Today Customer Return
						</div>
						<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e($return_amount); ?></div>

						<?php endif; ?>
					</div>

					<?php
					use App\Models\Due_Sales_Payment;

						$due_sales_payments = Due_Sales_Payment::whereDate('created_at', Carbon::today())->get();
					// $return_customer = Return_Sales_Invoice::all();
                        $sales_paid =0;
					?>

                    <?php $__currentLoopData = $due_sales_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $due_sales_payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $sales_paid += $due_sales_payment->paid_amount;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<div class="span3 statbox yellow" onTablet="span6" onDesktop="span3">
						<div class="boxchart"></div>

						<?php if(!$sales_paid): ?>

							<div class="">
								Today Sales Due Paid
							</div>
							<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e(0); ?></div>

						<?php endif; ?>

						<?php if($sales_paid): ?>

							<div class="">
								Today Sales Due Paid
							</div>
							<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e($sales_paid); ?></div>

						<?php endif; ?>


					</div>

				</div>

				<div class="title_info" style="width:90%">
					<h1 style="text-align: center">Purchase Information</h1>
				</div>

				<div class="row-fluid" style="margin-left:-3rem">

					<div class="span3 statbox purple" onTablet="span6" onDesktop="span3">
						<div class="boxchart"></div>
						<?php
							use App\Models\Purchase_invoice;
							$purchase_amounts = Purchase_invoice::whereDate('created_at', Carbon::today())->get();
                            $purchase_total =0;
                            $purchase_due =0;
						?>

                        <?php $__currentLoopData = $purchase_amounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase_amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $purchase_total += $purchase_amount->sub_total;
                            $purchase_due += $purchase_amount->due;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<?php if($purchase_total): ?>
							<div class="text-center" >
								Today Purchase Amount
							</div>
							<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e($purchase_total); ?></div>
							

						<?php else: ?>
							<div class="">
								Today Purchase Amount
							</div>
							<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e(0); ?></div>
							

						<?php endif; ?>
					</div>
					<div class="span3 statbox green" onTablet="span6" onDesktop="span3">
						<div class="boxchart"></div>
						<?php if($purchase_due): ?>
							<div class="">
								Today Purchase Due
							</div>
							<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e($purchase_due); ?></div>

						<?php else: ?>
							<div class="">
								Today Purchase Due
							</div>
							<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e(0); ?></div>

						<?php endif; ?>
					</div>

					<?php
						use App\Models\Return_Invoice;

						$return_customers = Return_Invoice::whereDate('created_at', Carbon::today())->get();
						// $return_customer = Return_Sales_Invoice::all();
                        $purchase_return_amount =0;
					?>
                    <?php $__currentLoopData = $return_customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $return_customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $purchase_return_amount += $return_customer->sub_total;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<div class="span3 statbox blue noMargin" onTablet="span6" onDesktop="span3">
						<div class="boxchart"></div>

						<?php if(!$purchase_return_amount): ?>

							<div class="">
								Today Purchase Return
							</div>
							<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e(0); ?></div>

						<?php endif; ?>
						<?php if($purchase_return_amount): ?>
							<div class="">
								Today Purchase Return
							</div>
							<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e($purchase_return_amount); ?></div>

						<?php endif; ?>
					</div>

					<?php
					use App\Models\Paid;

						$due_purchase_payments = Paid::whereDate('created_at', Carbon::today())->get();
					// $return_customer = Return_Sales_Invoice::all();
                    $purchase_paid_amount =0;
					?>

                    <?php $__currentLoopData = $due_purchase_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $due_purchase_payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $purchase_paid_amount += $due_purchase_payment->paid_amount;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<div class="span3 statbox yellow" onTablet="span6" onDesktop="span3">
						<div class="boxchart"></div>

						<?php if(!$purchase_paid_amount): ?>

							<div class="">
								Today Purchase Due Paid
							</div>
							<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e(0); ?></div>

						<?php endif; ?>

						<?php if($purchase_paid_amount): ?>

							<div class="">
								Today Purchase Due Paid
							</div>
							<div class="text-center" style="margin-top:2rem;font-size:1.4rem"><?php echo e($purchase_paid_amount); ?></div>

						<?php endif; ?>


					</div>

				</div>

				<div class="title_info" style="width:90%">
					<h1 style="text-align: center">Main Account & Expence Information</h1>
				</div>

				<div class="row-fluid" style="margin-left:-3rem">
					<?php
						use App\Models\Main_account;
						@$main_account = Main_account::first();
						// $main_accounts = Main_account::whereDate('created_at', Carbon::today())->get();
                        // $main_acco =0;
					?>

                    
					<?php if( $main_account): ?>
						<a class="quick-button metro red span3">
							
							<div class="">
								Today Cash
							</div>
							<div class="text-center" style="margin:1rem;font-size:1.4rem"><?php echo e($main_account->total_amount); ?></div>
						</a>
					<?php else: ?>
						<a class="quick-button metro red span3">
							
							<div class="">
								Today Cash
							</div>
							<div class="text-center" style="margin:1.3rem;font-size:1.4rem"><?php echo e(0); ?></div>
						</a>

					<?php endif; ?>
					

                <?php
                    use App\Models\Expence_Invoice;
                    use App\Models\Expence_Category;
                    $expences = Expence_Invoice::whereDate('created_at', Carbon::today())->get();
                    $expence_category = Expence_Category::latest()->first();
                    $expence_amount =0;

                ?>
                  <?php $__currentLoopData = $expences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $expence_amount += $expence->amount;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                <?php if($expence_amount): ?>
                <a class="quick-button metro pink  span3">
                    
                        
                        <div class="" >
                            Today Expence  <span style="margin:.01rem .3rem;font-size:1.2rem"><?php echo e($expence_amount); ?></span>
                            Expence Category  <span style="margin:.01rem .3rem;font-size:1.2rem"><?php echo e($expence_category->category); ?></span>
                        </div>
                        <div class="" style="margin:1rem;font-size:1.4rem"></div>
                </a>

                <?php else: ?>
                    <a class="quick-button metro pink  span3">
                        
                        <div class="" >
                        <div>	Today Expence  <span style="margin:.01rem .3rem;font-size:1.2rem"><?php echo e(0); ?></span></div><br>
                        <div>	Expence Category  <span style="margin:.01rem .3rem;font-size:1.2rem"><?php echo e(0); ?></span> </div>
                        </div>
                        <div class="" style="margin:1rem;font-size:1.4rem"></div>
                    </a>

                <?php endif; ?>


					
					

					<div class="clearfix"></div>

				</div><!--/row-->



			</div><!--/.fluid-container-->

			<!-- end: Content -->
		</div><!--/#content.span10-->
	</div><!--/fluid-row-->


	<!-- start: JavaScript-->


</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Suhail\Desktop\Inventory project\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>