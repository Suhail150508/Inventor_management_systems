<?php $__env->startSection('content'); ?>

<style>

    body {
    font-family: 'lato', sans-serif;
    }
    .container {
    max-width: 1000px;
    margin-left: auto;
    margin-right: auto;
    padding-left: 10px;
    padding-right: 10px;
    }

    h2 {
    font-size: 26px;
    margin: 80px 0;
    text-align: center;
    small {
        font-size: 0.5em;
    }
    }

    .responsive-table {
    li {
        border-radius: 3px;
        padding: 25px 30px;
        display: flex;
        justify-content: space-between;
        margin-bottom: 15px;
    }
    .table-header {
        background-color: #95A5A6;
        font-size: 14px;
        text-transform: uppercase;
        letter-spacing: 0.03em;
    }
    .table-row {
        background-color: #ffffff;
        box-shadow: 0px 0px 9px 0px rgba(0,0,0,0.1);
    }
    .col-1 {
        flex-basis: 10%;
    }
    .col-2 {
        flex-basis: 40%;
    }
    .col-3 {
        flex-basis: 25%;
    }
    .col-4 {
        flex-basis: 25%;
    }

    @media all and (max-width: 767px) {
        .table-header {
        display: none;
        }
        .table-row{

        }
        li {
        display: block;
        }
        .col {

        flex-basis: 100%;

        }
        .col {
        display: flex;
        padding: 10px 0;
        &:before {
            color: #6C7A89;
            padding-right: 10px;
            content: attr(data-label);
            flex-basis: 50%;
            text-align: right;
        }
        }
    }
    }

    @media (min-width: 700px) {


.form_section{
    display: flex;
    justify-content:center;
     flex-wrap:wrap;
     margin-top:3rem;
}

.discount{
    float: right;
    margin:4rem 2rem;
    background-color:#d9d9ebc6;
    padding:8px;
    font-size: 1rem;
}
.d_para{
    font-weight:bold;
    font-size:1rem;
}
.form_inner{
    margin: 0px 10px;
}

.print{
    /* margin-top:-3rem; */
    padding:3px 20px;
    font-size:1.3rem;
}

}
@media (max-width: 700px) {

.form_section{
    display: flex;
    justify-content:column;
     flex-wrap:wrap;
     margin-top:3rem;
     text-align: center;
     margin-left: 5rem;
}
.form_inner{
    margin-top: -10px;
}

.discount{
    float: right;
    margin:4rem 2rem;
    background-color:#d9d9ebc6;
    padding:8px;
    width:35%;
    font-size: 1rem;
}
.d_para{
    font-weight:bold;
    font-size:.9rem;
}
.print{
    font-size:1rem;

}
.box-header h2{
    font-size:1rem;
}

}

    @media print{
        .btn{
            display: none;
        }
        /* .form-control{
            border: 0px;
        } */
        input .form-control{
            border: 0px;
        }
        .customer .form-controll{
            display: none;
        }
        .customer{
            border:2px solid #000;
        }
        .customer-heading {
            /* display: block !important;
            background-color:#aaa !important;
            padding:4px; */
            /* margin-top: -3rem; */
            }
            /* .form-controll2{
                display: block;
            } */
            .origin{
                font-size: 2rem;
                /* background-color: #aaa !important; */
            }
            .origin1{
                background-color: #aaa !important;
                height: 200px;
                padding-top: 10px;
            }
            .first{
                margin-right: -6rem;
                width:300px;
            }
            h2{
                margin-top:-15rem;
                text-align: center;
                /* font-size: 30px; */
                /* margin: 35px; */
                font-weight: 300;
                color: tomato;
                /* padding: 50px; */
                /* width: 50px;
                border-bottom:2px solid black; */
            }
            #dataContainer{
                width:100px;
            }
            .form_section{
                display:none;
            }
            .breadcrumb{
                display:none;

            }
            .action{
                display:none;

            }
            .sub_total{
                margin-top:.06rem !important;
            }

    }
</style>

<body style="height: 100%">

    <div class="row-fluid sortable">
        <div class="box span12">
            <div class="box-header" data-original-title>
                <h2><i class="halflings-icon user"></i><span class="break"></span>Sales Invoices</h2>
                

                <div style="float: right;margin-right:2rem;">
                    <button type="button" class="btn print"  onclick="GetPrint()">Print</button>
                </div>

            </div>


            <div class="action">
                <form class="form_section" action="<?php echo e(url('/search-sales-invoice')); ?>" method="GET" >
                    <?php echo csrf_field(); ?>
                    <div class=" form_inner col-md-1">
                        <h4>Customers</h4>
                        <?php
                            $customers = App\Models\Customer::all();
                        ?>
                        <label for="">  </label>
                        <select class="form-control" type="textarea" name="customer_id" id="customer_id">
                            <option style="font-size:1.1rem" value="all">All Customers</option>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option style="font-size:1.1rem" value="<?php echo e($customer->id); ?>" <?php echo e(session('selectedCustomerId') == $customer->id ? 'selected' : ''); ?>><?php echo e($customer->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class= "form_inner col-md-1">
                        <h4>From</h4>
                        <div class="">
                            <input class="form-control" type="date" name="date_from" id="date_from" placeholder="2018-07-03" value="<?php echo e(request()->input('date_from')); ?>">
                        </div>
                    </div>
                    <div class= "form_inner col-md-1">
                        <h4>To</h4>
                        <div class="">
                            <input class="form-control" type="date" name="date_to" id="date_to" placeholder="2018-07-03" value="<?php echo e(request()->input('date_to')); ?>">
                        </div>
                    </div>
                    <div class="col-md-1" style="margin: 0px 10px">
                        
                        <button class="col-md-1 btn btn-secondary" type="submit" style="height: 2.3rem;margin:2rem 1rem">Search</button>
                    </div>
                </form>



            </div>

            <?php
                $total = 0;
                $invoice_discount = 0;
                $paid = 0;
                $due = 0;
            ?>
            <div class="box-content">
                <table class="table table-striped table-bordered bootstrap-datatable datatable">
                    <h3 style="text-align: center;margin-bottom:2rem">Paid & Unpaid Invoices</h3>
                    <thead>
                        <tr>
                            <th>Invoice Id</th>
                            <th>Customer Id</th>
                            <th>Sub Total</th>
                            <th>Discount</th>
                            <th>Total</th>
                            <th>Paid</th>
                            <th>Due</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th class="action">Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $sales_invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php
                                $total += $invoice->total;
                                $invoice_discount += $invoice->discount;
                                $paid += $invoice->paid;
                                $due += $invoice->due;
                                $customer_id = $invoice->customer_id;

                            ?>


                            <tr>
                                
                                <td class="center">#INV-000<?php echo e($invoice->id); ?></td>
                                <td class="center"><?php echo e($invoice->customer_id); ?></td>
                                <td class="center"><?php echo e($invoice->sub_total); ?></td>
                                <td class="center"><?php echo e($invoice->discount); ?></td>
                                <td class="center"><?php echo e($invoice->total); ?></td>
                                <td class="center"><?php echo e($invoice->paid); ?></td>
                                <td class="center"><?php echo e($invoice->due); ?></td>
                                <td class="center"><?php echo e($invoice->status); ?></td>
                                <td class="center"><?php echo e($invoice->created_at); ?></td>

                                <td class="center action">

                                    <div class="span2">
                                        <?php if($invoice->status && $invoice->status == 'Paid'): ?>
                                            <a class="btn btn-info" href="<?php echo e(url('/sales-invoice-show/'.$invoice->id)); ?>" style="margin-left:.1rem; border-radius: 25%;">
                                                <i class=" white icon-eye-open"></i>
                                            </a>
                                        <?php else: ?>
                                            <a class="btn btn-info" href="<?php echo e(url('/sales-invoice-edit/'.$invoice->id)); ?>" style="margin-left:.1rem;border-radius:25%">
                                                <i class="halflings-icon white edit"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>

                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </tbody>
                </table>
                <table class="table table-striped table-bordered bootstrap-datatable datatable">

                        <h3 style="text-align: center;margin:2rem 0px"> Due Paid Invoices</h3>
                    <thead>
                        <tr>
                            <th>Invoice Id</th>
                            <th>Customer Id</th>
                            <th>Paid Amount</th>
                            <th>Discount</th>
                            <th>Discription</th>
                            <th>Date</th>
                            <th class="action">Actions</th>
                        </tr>
                    </thead>
                            <?php
                                $paid_amount =0;
                                $discount = 0;
                            ?>
                    <tbody>
                        <?php $__currentLoopData = $due_sales_payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php
                                $paid_amount += $invoice->paid_amount;
                                $discount += $invoice->discount;

                            ?>


                            <tr>
                                
                                <td class="center">#INV-000<?php echo e($invoice->id); ?></td>
                                <td class="center"><?php echo e($invoice->customer_id); ?></td>
                                <td class="center"><?php echo e($invoice->paid_amount); ?></td>
                                <td class="center"><?php echo e($invoice->discount); ?></td>
                                <td class="center"><?php echo e($invoice->description); ?></td>
                                <td class="center"><?php echo e($invoice->created_at); ?></td>

                                
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </tbody>
                </table>

                    <?php
                    $total_paid = $paid + $paid_amount;
                    $total_due = $due - ($paid_amount + $discount);
                    $total_discount = $invoice_discount + $discount;
                    ?>

                    <div  class="sub_total discount">
                        <p class="d_para">Invoice Total: <?php echo e($total); ?>  </p>
                        <p class="d_para">Total Discount: <?php echo e($total_discount); ?> </p>
                        <p class="d_para">Total Paid: <?php echo e($total_paid); ?> </p>
                        <p class="d_para">Total Due: <?php echo e($total_due); ?> </p>
                    </div>
            </div>
        </div>
    </div>



    <script>

        function GetPrint(){
            window.print();
        }

    </script>

</body>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Suhail\Desktop\Inventory project\resources\views/sales/all_sales_invoice.blade.php ENDPATH**/ ?>