<?php $__env->startSection('content'); ?>

<style>

    body {
    font-family: 'lato', sans-serif;
    }
    .container {
    max-width: 1000px;
    margin-left: auto;
    margin-right: auto;
    padding-left: 10px;
    padding-right: 10px;
    }

    h2 {
    font-size: 26px;
    margin: 80px 0;
    text-align: center;
    small {
        font-size: 0.5em;
    }
    }

    .responsive-table {
    li {
        border-radius: 3px;
        padding: 25px 30px;
        display: flex;
        justify-content: space-between;
        margin-bottom: 15px;
    }
    .table-header {
        background-color: #95A5A6;
        font-size: 14px;
        text-transform: uppercase;
        letter-spacing: 0.03em;
    }
    .table-row {
        background-color: #ffffff;
        box-shadow: 0px 0px 9px 0px rgba(0,0,0,0.1);
    }
    .col-1 {
        flex-basis: 10%;
    }
    .col-2 {
        flex-basis: 40%;
    }
    .col-3 {
        flex-basis: 25%;
    }
    .col-4 {
        flex-basis: 25%;
    }

    @media all and (max-width: 767px) {
        .table-header {
        display: none;
        }
        .table-row{

        }
        li {
        display: block;
        }
        .col {

        flex-basis: 100%;

        }
        .col {
        display: flex;
        padding: 10px 0;
        &:before {
            color: #6C7A89;
            padding-right: 10px;
            content: attr(data-label);
            flex-basis: 50%;
            text-align: right;
        }
        }
    }
    }
</style>

<ul class="breadcrumb">
    <li>
        <i class="icon-home"></i>
        <a href="/">Home</a>
        <i class="icon-angle-right"></i>
    </li>
    <li><a href="#">Invoices</a></li>
</ul>

<div class="row-fluid sortable">
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon user"></i><span class="break"></span>Customer Due Payment</h2>
        </div>


        <div>

            <form action="<?php echo e(url('/search-customer-due-payment')); ?>" method="GET" style="display: flex;justify-content:center; flex-wrap:wrap;margin-top:5rem">
                <?php echo csrf_field(); ?>
                <div class=" col-md-1" style="margin: 0px 10px">
                    <h4>Customers</h4>
                    <?php
                        $customers = App\Models\Customer::all();
                    ?>
                    <label for="">  </label>
                    <select type="text" name="customer_id" id="vendor_id">
                        <option style="font-size:1.1rem" value="all">All Customers</option>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option style="font-size:1.1rem" value="<?php echo e($customer->id); ?>" <?php echo e(session('selectedCustomerId') == $customer->id ? 'selected' : ''); ?>><?php echo e($customer->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-1" style="margin: 0px 10px">
                    <h4>From</h4>
                    <div class="">
                        <input type="date" name="date_from" id="date_from" placeholder="2018-07-03" value="<?php echo e(request()->input('date_from')); ?>">
                    </div>
                </div>
                <div class="col-md-1" style="margin: 0px 10px">
                    <h4>To</h4>
                    <div class="">
                        <input type="date" name="date_to" id="date_to" placeholder="2018-07-03" value="<?php echo e(request()->input('date_to')); ?>">
                    </div>
                </div>
                <button class="col-md-1 btn btn-secondary" type="submit" style="height: 2rem;margin:2rem 1rem">Search</button>
            </form>


        </div>

        <?php
            $total = 0;
            $paid = 0;
            $due = 0;
        ?>
        <div class="box-content">
            <table class="table table-striped table-bordered bootstrap-datatable datatable">
              <thead>
                  <tr>
                      <th>Id</th>
                      <th>Customer Id</th>
                      <th>Paid Amount</th>
                      <th>Discount</th>
                      <th>Description</th>
                      <th>Date</th>
                      
                  </tr>
              </thead>

              <tbody>
            <?php $__currentLoopData = $paid_invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                    $paid += $invoice->paid_amount;

                ?>


                    <tr>
                        <td class="center">#INV-000<?php echo e($key+1); ?></td>
                        <td class="center"><?php echo e($invoice->customer_id); ?></td>
                        <td class="center"><?php echo e($invoice->paid_amount); ?></td>
                        <td class="center"><?php echo e($invoice->discount); ?></td>
                        <td class="center"><?php echo e($invoice->description); ?></td>
                        <td class="center"><?php echo e($invoice->created_at); ?></td>
                        
                    </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
              </tbody>
          </table>
                <div style="float: right;margin:4rem 2rem;background-color:#d9d9ebc6;padding:8px;width:21%;">
                    <p style="font-weight:bold;font-size:1rem">Total Paid: <?php echo e($paid); ?> </p>
                </div>
        </div>
    </div>
</div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Suhail\Desktop\Inventory project\resources\views/sales/due_sales_payment.blade.php ENDPATH**/ ?>