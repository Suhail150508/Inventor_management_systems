<?php $__env->startSection('content'); ?>

<style>

    body {
    font-family: 'lato', sans-serif;
    }
    .container {
    max-width: 1000px;
    margin-left: auto;
    margin-right: auto;
    padding-left: 10px;
    padding-right: 10px;
    }

    h2 {
    font-size: 26px;
    margin: 80px 0;
    text-align: center;
    small {
        font-size: 0.5em;
    }
    }

    .responsive-table {
    li {
        border-radius: 3px;
        padding: 25px 30px;
        display: flex;
        justify-content: space-between;
        margin-bottom: 15px;
    }
    .table-header {
        background-color: #95A5A6;
        font-size: 14px;
        text-transform: uppercase;
        letter-spacing: 0.03em;
    }
    .table-row {
        background-color: #ffffff;
        box-shadow: 0px 0px 9px 0px rgba(0,0,0,0.1);
    }
    .col-1 {
        flex-basis: 10%;
    }
    .col-2 {
        flex-basis: 40%;
    }
    .col-3 {
        flex-basis: 25%;
    }
    .col-4 {
        flex-basis: 25%;
    }

    @media all and (max-width: 767px) {
        .table-header {
        display: none;
        }
        .table-row{

        }
        li {
        display: block;
        }
        .col {

        flex-basis: 100%;

        }
        .col {
        display: flex;
        padding: 10px 0;
        &:before {
            color: #6C7A89;
            padding-right: 10px;
            content: attr(data-label);
            flex-basis: 50%;
            text-align: right;
        }
        }
    }
    }
</style>

<ul class="breadcrumb">
    <li>
        <i class="icon-home"></i>
        <a href="/">Home</a>
        <i class="icon-angle-right"></i>
    </li>
    <li><a href="#">Invoices</a></li>
</ul>

<div class="row-fluid sortable">
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon user"></i><span class="break"></span>Invoices</h2>
            
        </div>


        <div>
            <form action="/search-vendor-invoice" method="POST" class="row pt-5" style="width:50%;height:40%;display:flex;justify-content:center;padding:.2rem;margin:.9rem 5rem">
                <?php echo csrf_field(); ?>
                <?php
                    $vendors = App\Models\Vendor::all();
                ?>

                <strong style="font-size:1.2rem" for=""> Vendors </strong>
                <select  name="vendor_id"  id="selectField">

                    <option style="font-size:1.1rem" value="All">All</option>
                    <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option style="font-size:1.1rem" value="<?php echo e($vendor->id); ?>" <?php echo e(session('selectedVendorId') == $vendor->id ? 'selected' : ''); ?>><?php echo e($vendor->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="col-md-3 btn btn-success" style="font-size:1.2rem;width:100px;height:32px">Search </button>
            </form>
        </div>

        <?php
            $total = 0;
            $paid = 0;
            $due = 0;
        ?>
        <div class="box-content">
            <table class="table table-striped table-bordered bootstrap-datatable datatable">
              <thead>
                  <tr>
                      <th>Invoice Id</th>
                      <th>Vendor Id</th>
                      <th>Sub Total</th>
                      <th>Discount</th>
                      <th>Total</th>
                      <th>Paid</th>
                      <th>Due</th>
                      <th>Actions</th>
                  </tr>
              </thead>

              <tbody>
            <?php $__currentLoopData = $purchase_invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                    $total += $invoice->total;
                    $paid += $invoice->paid;
                    $due += $invoice->due;
                    $vendor_id = $invoice->vendor_id;

                ?>


                    <tr>
                        <td class="center">#INV-000<?php echo e($invoice->id); ?></td>
                        <td class="center"><?php echo e($invoice->vendor_id); ?></td>
                        <td class="center"><?php echo e($invoice->sub_total); ?></td>
                        <td class="center"><?php echo e($invoice->discount); ?></td>
                        <td class="center"><?php echo e($invoice->total); ?></td>
                        <td class="center"><?php echo e($invoice->paid); ?></td>
                        <td class="center"><?php echo e($invoice->due); ?></td>



                        <td class="center">

                            <div class="span2">

                                <a class="btn btn-info" href="<?php echo e(url('/return-purchase-invoice-edit/'.$invoice->id)); ?>" style="margin-left:.1rem;border-radius:25%">
                                    <i class="halflings-icon white edit"></i>
                                </a>
                            </div>

                        </td>
                    </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
              </tbody>
          </table>

                <div style="float: right;margin:4rem 2rem;background-color:#d9d9ebc6;padding:8px;width:21%;">
                    <p style="font-weight:bold;font-size:1rem">Total: <?php echo e($total); ?>  </p>
                    <p style="font-weight:bold;font-size:1rem">Total Paid: <?php echo e($paid); ?> </p>
                    <p style="font-weight:bold;font-size:1rem">Total Due: <?php echo e($due); ?> </p>
                </div>
        </div>
    </div>
</div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Suhail\Desktop\Inventory project\resources\views/purchase/all_return_purchase_invoice.blade.php ENDPATH**/ ?>