<?php $__env->startSection('content'); ?>

<style>

body {
  font-family: 'lato', sans-serif;
}
.container {
  max-width: 1000px;
  margin-left: auto;
  margin-right: auto;
  padding-left: 10px;
  padding-right: 10px;
}

h2 {
  font-size: 26px;
  margin: 80px 0;
  text-align: center;
  small {
    font-size: 0.5em;
  }
}

.responsive-table {
  li {
    border-radius: 3px;
    padding: 25px 30px;
    display: flex;
    justify-content: space-between;
    margin-bottom: 15px;
  }
  .table-header {
    background-color: #95A5A6;
    font-size: 14px;
    text-transform: uppercase;
    letter-spacing: 0.03em;
  }
  .table-row {
    background-color: #ffffff;
    box-shadow: 0px 0px 9px 0px rgba(0,0,0,0.1);
  }
  .col-1 {
    flex-basis: 10%;
  }
  .col-2 {
    flex-basis: 40%;
  }
  .col-3 {
    flex-basis: 25%;
  }
  .col-4 {
    flex-basis: 25%;
  }

  @media all and (max-width: 767px) {
    .table-header {
      display: none;
    }
    .table-row{

    }
    li {
      display: block;
    }
    .col {

      flex-basis: 100%;

    }
    .col {
      display: flex;
      padding: 10px 0;
      &:before {
        color: #6C7A89;
        padding-right: 10px;
        content: attr(data-label);
        flex-basis: 50%;
        text-align: right;
      }
    }
  }
}


/* HTML: <div class="loader"></div> */
.loader {
  width: 50px;
  aspect-ratio: 1;
  display: grid;
  animation: l14 4s infinite;
}
.loader::before,
.loader::after {
  content: "";
  grid-area: 1/1;
  border: 8px solid;
  border-radius: 50%;
  border-color: red red #0000 #0000;
  mix-blend-mode: darken;
  animation: l14 1s infinite linear;
}
.loader::after {
  border-color: #0000 #0000 blue blue;
  animation-direction: reverse;
}
@keyframes l14{
  100%{transform: rotate(1turn)}
}
</style>

<ul class="breadcrumb">
    <li>
        <i class="icon-home"></i>
        <a href="/">Home</a>
        <i class="icon-angle-right"></i>
    </li>
    <li><a href="#">customers</a></li>
</ul>

<div class="row-fluid sortable">
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon user"></i><span class="break"></span>All Products</h2>
            
        </div>


        


        <div class="box-content" style="margin-top:4rem">
            <table class="table table-striped table-bordered bootstrap-datatable datatable">
              <thead>
                  <tr>
                      <th>Id</th>
                      <th>Photo</th>
                      <th>Name</th>
                      <th>Code</th>
                      <th>Origin</th>
                      <th>Year</th>
                      <th>Unit Amount</th>
                      <th>Sales Amount</th>
                      <th>Quantity</th>
                      <th>Status</th>
                      <th>Expire Date</th>
                      <th>Actions</th>
                  </tr>
              </thead>

              <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="center"><?php echo e($key+1); ?></td>
                        <td class="center">
                            <img width="50" style="border-radius:25%" src="<?php echo e(URL::asset('/teacher/'.$product->image)); ?>" alt="<?php echo e($product->image); ?>">
                        </td>
                        <td class="center"><?php echo e($product->name); ?></td>
                        <td class="center"><?php echo e($product->code); ?></td>
                        <td class="center"><?php echo e($product->origin); ?></td>
                        <td class="center"><?php echo e($product->year); ?></td>
                        <td class="center"><?php echo e($product->unit_amount); ?></td>
                        <td class="center"><?php echo e($product->sales_amount); ?></td>
                        <td class="center"><?php echo e($product->quantity); ?></td>
                        <td class="center"><?php echo e($product->status); ?></td>
                        <td class="center"><?php echo e($product->expire_date); ?></td>
                        
                        <td class="center">
                            

                            <div class="span5">

                                <a class="btn btn-info" href="<?php echo e(url('/product-edit/'.$product->id)); ?>" style="margin-left:.1rem;border-radius:25%;">
                                    <i class="halflings-icon white edit"></i>
                                </a>
                            </div>

                            <div class="span1">
                                <form method="post" action="<?php echo e(url('/product-delete/'.$product->id )); ?>" style="margin-left:.1;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger"> <i class="halflings-icon white trash"></i></button>

                                </form>
                            </div>

                        </td>
                    </tr>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
              </tbody>
          </table>
        </div>
    </div>
</div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Suhail\Desktop\Inventory project\resources\views/vendor/purchase_product.blade.php ENDPATH**/ ?>